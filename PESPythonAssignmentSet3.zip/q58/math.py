#math.py
from calc import*
add(4,5)
diff(34,12)
multiply(5,7)
div(6,2)
sqroot(9)
floor_div(33,5)
fib(8)
isprime(443)
