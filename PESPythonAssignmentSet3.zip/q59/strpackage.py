from stringop import*
sortNumbers([34,56,21,11,3])
print "binarySearch([22,33,44,12,34]):", binarySearch([22,33,44,12,34],22)
reverselist([11,22,12,10,32,13])
