#File I/O Operations
'''49.Write a program to perform following file operations
a) Open the file in read mode and read all its contents on to STDOUT.
b) Open the file in write mode and enter 5 new lines of strings in to the new file.
c) Open file in Append mode and add 5 lines of text into it.'''

fo = open("readme.txt","r")
print "Read String is : ",fo.read()
fo.close()

fo=open("testfile.txt","w")
fo.writelines("Hi! I'm Saptak\nI'm a Software Engg\nPython is my forte skill\n I love Data\n Company is awesome")
fo.close()


fo=open("testfile.txt","a")
fo.writelines("finally\nI have appended this line\n even this one\n4th line\n5th line")
fo.close()
